#!/bin/bash

# Đường dẫn đến AstroMiner
ASTRO_MINER_PATH="./astrominer"

# Địa chỉ ví DERO
WALLET_ADDRESS="deroi1qy9al37a8qgjmat4y9wf5wc637md58jtt6p4980k34xxhrk2h9m6jq9pvfz92xcqqqqextxqgv3qaljzwm"

# Node DERO
DERO_NODE="dero-node.mysrv.cloud"

# Chạy AstroMiner
$ASTRO_MINER_PATH -w $WALLET_ADDRESS -r $DERO_NODE -p rpc